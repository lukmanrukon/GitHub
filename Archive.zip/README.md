# Quasar Ledger App
 Simple business in and out record
 Demo https://simple-ledger-app.netlify.com/
