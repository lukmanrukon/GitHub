<template>
  <q-page class="q-pa-lg">
    <h5 class="q-mt-none"> Help</h5>
    <p>A Test Hybrid App</p>
  </q-page>
</template>

<script>
export default {
  name: 'Help'
}
</script>
